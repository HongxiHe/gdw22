using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Animations;

public class Small_sin : MonoBehaviour
{
    private Transform player;
    NavMeshAgent nav;
    private float hp = 3f;
    float attackTime = 0f;
    Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        nav = GetComponent<NavMeshAgent>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        nav.SetDestination(player.position);

        if (attackTime >= 0)
        {
            attackTime -= Time.deltaTime;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "Player")
        {

            if (attackTime <= 0)
            {
                Debug.Log("damage to player");
                anim.SetBool("Attacking", true);
                anim.SetBool("Walking", false);
                attackTime = 5f;

            }

        }
        if (collision.collider.tag == "Bullet")
        {
            hp--;

            if (hp <= 0)
            {
                Destroy(gameObject);
            }
        }

      
            
        
        

    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.collider.tag == "Player")
        {
            if (attackTime <= 0)
            {
                Debug.Log("damage to player");
                attackTime = 5f;
                anim.SetBool("Attacking", true);
                anim.SetBool("Walking", false);

            }

        }
    }




    private void OnCollisionExit(Collision collision)
    {
        if (collision.collider.tag == "Player")
        {

            anim.SetBool("Attacking", false);
            anim.SetBool("Walking", true);
        }
    }
}
