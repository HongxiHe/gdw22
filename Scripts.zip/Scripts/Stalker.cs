using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stalker : MonoBehaviour
{
    public BoxCollider2D collider;
    private bool isUp;
    private bool animUp;
    public float minD;
    public float maxD;    
    public float minU;
    public float maxU;
    private float coolDown;
    private float upTime;
    private Animator _animator;


    // Start is called before the first frame update
    void Start()
    {
        collider = GetComponent<BoxCollider2D>();
        animUp = TryGetComponent<Animator>(out _animator);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        RandTime();
        if (isUp)
        {
            if (coolDown > 0)
            {
                coolDown -= Time.deltaTime;
            }
            else if (coolDown < 0)
            {
                Rising();
                coolDown = 0;
            }
            if (collider.enabled == true)
            {
                Stalking();
            }
        }
    }

    public void Rising()
    {
        _animator.SetBool("Rising", true);
    }

    public void Collider()
    {
        collider.enabled = true;
    }

    public void Down()
    {
        _animator.SetBool("Lowering", false);
        isUp = false;
    }

    public void Stalking()
    {
        _animator.SetBool("Rising", false);
        _animator.SetBool("Stalking", true);
        if (upTime > 0)
        {
            upTime -= Time.deltaTime;
        }
        if (upTime < 0)
        {
            collider.enabled = false;
            _animator.SetBool("Stalking", false);
            _animator.SetBool("Lowering", true);
        }
    }

    public void RandTime()
    {
        if (!isUp)
        {
            coolDown = Random.Range(minD, maxD);
            upTime = Random.Range(minU, maxU);
            isUp = true;
        }
    }
}
